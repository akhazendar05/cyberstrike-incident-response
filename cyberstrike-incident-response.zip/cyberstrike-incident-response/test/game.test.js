const test = require("node:test");
const assert = require("node:assert/strict");
const { internals } = require("../server");

test("game has five rounds and all rounds reference known incidents", () => {
  assert.equal(internals.ROUNDS.length, 5);
  const known = new Set(internals.INCIDENTS.map(i => i.id));
  for (const round of internals.ROUNDS) for (const id of round.incidentIds) assert.ok(known.has(id), `unknown incident ${id}`);
});
test("player limit and minimum-player rules are configured", () => {
  assert.equal(internals.MAX_PLAYERS, 8);
  assert.equal(internals.MIN_PLAYERS, 2);
});
test("scoring awards 100 severity, 100 priority, 150 action and up to 50 speed points", () => {
  const incident = { severity:"critical", priority:"P1", action:"isolate-host" };
  const perfectFast = internals.scoreSubmission(incident, {severity:"critical",priority:"P1",action:"isolate-host"}, 0);
  assert.equal(perfectFast.points, 400);
  assert.equal(perfectFast.speedBonus, 50);
  const perfectSlow = internals.scoreSubmission(incident, {severity:"critical",priority:"P1",action:"isolate-host"}, 45000);
  assert.equal(perfectSlow.points, 350);
  const twoCorrect = internals.scoreSubmission(incident, {severity:"critical",priority:"P2",action:"isolate-host"}, 1000);
  assert.equal(twoCorrect.points, 250);
  assert.equal(twoCorrect.speedBonus, 0);
});
test("player names are trimmed, bounded and strip angle brackets", () => {
  assert.equal(internals.cleanName("  <Packet> Pilot  "), "Packet Pilot");
  assert.equal(internals.cleanName("A".repeat(30)).length, 20);
  assert.equal(internals.cleanName("   "), "");
});
test("incident IDs are unique", () => {
  const ids = internals.INCIDENTS.map(i=>i.id);
  assert.equal(new Set(ids).size, ids.length);
});
